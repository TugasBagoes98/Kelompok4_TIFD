sebelum import sql, buat database bernama db_belajar_php
kemudian masuk ke db_belajar_php, kemudian import